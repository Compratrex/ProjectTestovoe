#include <SFML/Graphics.hpp>
#include <SFML/Network.hpp>
#include <cassert>
#include <iostream>
#include <vector>
#include <cmath>
#include <ctime>
#include <string>
//#include <filesystem>
#include "Textbox.h"
#include "Button.h"
#include "keys_to_string.h"
using namespace std;
using namespace sf;


sf::TcpSocket socket;
sf::Socket::Status status = socket.connect("127.0.0.1", 53210);
sf::Text server_response;
//string GetCurrentWorkingDir() {
//    string path = std::filesystem::canonical(std::filesystem::current_path());
//    int index = 0;
//    for (int i = path.size(); i > 0; --i) {
//        if (path[i] == '/') {
//            index = i + 1;
//            break;
//        }
//    }
//    string normilzed_path = "";
//    for (int i = 0; i < path.size(); ++i) {
//        if (i == index) {
//            break;
//        }
//        normilzed_path += path[i];
//    }
//    cout << normilzed_path << endl;
//    return normilzed_path;
//}


int GetRandomNumber(int min, int max) {
    int num = min + rand() % (max - min + 1);

    return num;
}

float getAngle(float x1, float y1, float x2, float y2) {
    sf::Vector2f p0(x1, y1);
    sf::Vector2f p1(x2, y2);
    sf::Vector2f q = p1 - p0;

    float q_length = sqrtf(q.x * q.x + q.y * q.y);

    q.x /= q_length;
    q.y /= q_length;

    float scalar_product = q.y;

    float angle = acos(scalar_product) * 180.0f / 3.1415f;

    if (x2 - x1 < 0.0f)
        return angle;
    else
        return -angle;
}

const int WIDTH = 800;
const int HEIGHT = 600;
//const auto CURR_PATH = GetCurrentWorkingDir();
sf::RenderWindow sfmlWin(sf::VideoMode(WIDTH, HEIGHT), "Asteroids game");

struct ShipInfo {
    float x;
    float y;
};
struct MouseInfo {
    Vector2i pixelPos = Mouse::getPosition(sfmlWin);
    float x = sfmlWin.mapPixelToCoords(pixelPos).x;
    float y = sfmlWin.mapPixelToCoords(pixelPos).y;
};

struct ShipAmmo {
    sf::RectangleShape ammo;
    float x;
    float y;
    bool out_from_screen = false;

};
enum class AsteroidsSize {
    SMALL,
    MEDIUM,
    BIG
};
enum class GameScenes {
    AUTH,
    REGISTER,
    GAME
};

sf::ConvexShape CreateAsteroid(const AsteroidsSize &size) {
    int points = 16;
    int R = 0;
    int ast_damage_vx_begin = 5;
    int ast_damage_vx_end = 14;

    sf::ConvexShape asteroid(points);

    if (size == AsteroidsSize::SMALL) {
        R = 16;
    } else if (size == AsteroidsSize::MEDIUM) {
        R = 32;
    } else if (size == AsteroidsSize::BIG) {
        R = 64;
    }

    sf::CircleShape shape(R, points);

    for (int i = 0; i < points; ++i) {
        sf::Vector2f vec = shape.getPoint(i);
        int rand_x = GetRandomNumber(ast_damage_vx_begin, ast_damage_vx_end);
        int rand_y = GetRandomNumber(ast_damage_vx_begin, ast_damage_vx_end);
        asteroid.setPoint(i, sf::Vector2f(vec.x - rand_x, vec.y - rand_y));
    }

    asteroid.setFillColor(sf::Color::Black);
    asteroid.setOutlineColor(sf::Color::White);
    asteroid.setOutlineThickness(1);
    asteroid.setOrigin(sf::Vector2f(asteroid.getLocalBounds().width, asteroid.getLocalBounds().height) / 2.f);
    asteroid.setPosition(1000, 500 + GetRandomNumber(-500, 500));

    return asteroid;
}

struct Asteroids {
    sf::ConvexShape asteroid;
    int shots = 3;
};

void SendInfoToServer(const float &x, const float &y, const float &angle, const vector<sf::Keyboard::Key> &vec) {
    sf::Http::Request request("/telemetry/", sf::Http::Request::Post);

    string req_body = "x=" + to_string(x) + "&y=" + to_string(y) + "&angle=" + to_string(angle) + "&keys=";
    bool is_first = true;
    for (const auto &key: vec) {
        if (is_first) {
            req_body += to_string(key) + ",";
            is_first = false;
        } else {
            req_body += "," + to_string(key);
        }
    }
    request.setBody(req_body);

    sf::Http http("127.0.0.1", 8000);
    sf::Http::Response response = http.sendRequest(request);

    if (response.getStatus() == sf::Http::Response::Ok) {
        std::cout << response.getBody() << std::endl;
    } else {
        std::cout << "request failed" << std::endl;
    }
}

bool Auth(string name, string password) {
    sf::Http::Request request("/auth/", sf::Http::Request::Post);


    string body = "username=" + name + "&password=" + password;
    request.setBody(body);
    sf::Http http("127.0.0.1", 8000);

    cout << body << endl;

    sf::Http::Response response = http.sendRequest(request);
    if (response.getStatus() == sf::Http::Response::Ok) {
        cout << response.getBody() << endl;
        server_response.setString(response.getBody());
        if (response.getBody() == "success") {
            return true;
        }
    } else {
        server_response.setString("Problem with code: " + to_string(response.getStatus()));
    }
    return false;
}

void RegisterUser(string &name, string &password) {
    sf::Http::Request request("/register/", sf::Http::Request::Post);

    string body = "username=" + name + "&password=" + password;
    request.setBody(body);
    sf::Http http("127.0.0.1", 8000);

    cout << body << endl;

    sf::Http::Response response = http.sendRequest(request);
    if (response.getStatus() == sf::Http::Response::Ok) {
        cout << response.getBody() << endl;
    } else {
        cout << "Nope" << endl;
    }
}

template<typename Shape>
void RollBackToScreen(Shape &shape) {
    if (!(shape.getPosition().x < WIDTH && shape.getPosition().y < HEIGHT &&
          shape.getPosition().x > 0 && shape.getPosition().y > 0)) {
        if (shape.getPosition().x < -shape.getGlobalBounds().width) {
            shape.setPosition(WIDTH + 50, shape.getPosition().y);
        } else if (shape.getPosition().x > WIDTH + 60) {
            shape.setPosition(-10.f, shape.getPosition().y);
        } else if (shape.getPosition().y < -shape.getGlobalBounds().width) {
            shape.setPosition(shape.getPosition().x, HEIGHT + 50);
        } else if (shape.getPosition().y > HEIGHT + 60) {
            shape.setPosition(shape.getPosition().x, -10.f);
        }
    }
}

void SetVelocity(float &velocity_x, float &velocity_y, MouseInfo &mouse, sf::Sprite &sprite, const float &velocity_kf) {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W)) {

        float distance = sqrt((mouse.x - sprite.getPosition().x) * (mouse.x - sprite.getPosition().x) +
                              (mouse.y - sprite.getPosition().y) * (mouse.y - sprite.getPosition().y));
        if (distance > 1) {
            velocity_x = velocity_kf * (mouse.x - sprite.getPosition().x) / distance;
            velocity_y = velocity_kf * (mouse.y - sprite.getPosition().y) / distance;
        }
    }
}

void SetSmoothVelocity(float &velocity_x, float &velocity_y) {
    if (velocity_x < 0) {
        velocity_x += 0.00001f;
    } else {
        velocity_x -= 0.00001f;
    }
    if (velocity_y < 0) {
        velocity_y += 0.00001f;
    } else {
        velocity_y -= 0.00001f;
    }
}

void Fire(int &counter, sf::Sprite &main_ship, MouseInfo &mouse, vector<ShipAmmo> &ammo_cont) {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space)) {
        ++counter;
        if (counter > 1000 || counter == 0) {
            float ammo_velocity_kf = 0.3f;
            sf::RectangleShape ammo(sf::Vector2f(4, 4));
            ammo.setPosition(main_ship.getPosition().x, main_ship.getPosition().y);
            float distance = sqrt((mouse.x - ammo.getPosition().x) * (mouse.x - ammo.getPosition().x) +
                                  (mouse.y - ammo.getPosition().y) * (mouse.y - ammo.getPosition().y));
            float ammo_velocity_x = ammo_velocity_kf * (mouse.x - ammo.getPosition().x) / distance;
            float ammo_velocity_y = ammo_velocity_kf * (mouse.y - ammo.getPosition().y) / distance;
            ammo_cont.push_back({ammo, ammo_velocity_x, ammo_velocity_y});
            counter = 0;
        }
    }
}

template<typename Shape>
float SetPointToMouse(Shape &shape, MouseInfo mouse) {
    float angle = getAngle(shape.getPosition().x, shape.getPosition().y, mouse.x, mouse.y);
    shape.setRotation(angle + 180);
    return angle;
}

void IteratingLogic(vector<ShipAmmo> &ammo_container, vector<Asteroids> &asteroids_container, sf::Sprite &sprite) {
    for (auto &element: ammo_container) {
        if (element.ammo.getPosition().x < WIDTH && element.ammo.getPosition().y < HEIGHT &&
            element.ammo.getPosition().x > 0 && element.ammo.getPosition().y > 0) {

            element.ammo.move(element.x, element.y);

        } else {
            element.out_from_screen = true;
        }
        for (auto &ast: asteroids_container) {
            if (element.ammo.getGlobalBounds().intersects(ast.asteroid.getGlobalBounds()) && ast.shots > 0) {
                if (!element.out_from_screen) {
                    --ast.shots;
                    element.out_from_screen = true;
                }
            }
        }
        if (!element.out_from_screen) {
            sfmlWin.draw(element.ammo);
        }
    }
    for (auto &element: ammo_container) {
        if (ammo_container.size() >= 20) {
            ammo_container.erase(ammo_container.begin(), ammo_container.begin() + 10);
        }

    }
    for (auto &element: asteroids_container) {
        sf::ConvexShape ast = element.asteroid;
        if (ast.getPosition().x < WIDTH && ast.getPosition().y < HEIGHT &&
            ast.getPosition().x > 0 && ast.getPosition().y > 0 && element.shots > 0) {
            if (sprite.getGlobalBounds().intersects(ast.getGlobalBounds())) {
                // -= lives;
            }
            sfmlWin.draw(ast);
        }
    }
}

void serverSendTelemetry(sf::Clock &clock, const vector<sf::Keyboard::Key> &keys, sf::Sprite &sprite, float &angle) {
    sf::Time elapsed = clock.getElapsedTime();
    if (elapsed.asSeconds() > 0.5f) {
        vector<sf::Keyboard::Key> keys_to_send = {};
        for (const auto &key: keys) {
            if (sf::Keyboard::isKeyPressed(key)) {
                keys_to_send.push_back(key);
            }
        }
        SendInfoToServer(sprite.getPosition().x, sprite.getPosition().y, angle, keys_to_send);
        clock.restart();
    }
}
string SendMessTCP(const string &data) {
    if (status != sf::Socket::Done) {
        server_response.setString("Server Problems");
    } else {
        const char *str = data.c_str();
        socket.send(str, data.size());
        char rev_data[3];
        std::size_t received;
        if (socket.receive(rev_data, 3, received) == sf::Socket::Done) {
            string code = "";
            for (int i = 0; i < received; ++i) {
                code += rev_data[i];
            }
            cout << "Recieved " << code << endl;
            return code;
        }
    }
    return "500";
}
vector<sf::Keyboard::Key> keys = {sf::Keyboard::A, sf::Keyboard::B, sf::Keyboard::C, sf::Keyboard::D,
                                  sf::Keyboard::E, sf::Keyboard::F, sf::Keyboard::G, sf::Keyboard::H,
                                  sf::Keyboard::I, sf::Keyboard::J, sf::Keyboard::K, sf::Keyboard::L,
                                  sf::Keyboard::M, sf::Keyboard::N, sf::Keyboard::O, sf::Keyboard::P,
                                  sf::Keyboard::Q, sf::Keyboard::R, sf::Keyboard::S, sf::Keyboard::T,
                                  sf::Keyboard::U, sf::Keyboard::V, sf::Keyboard::W, sf::Keyboard::X,
                                  sf::Keyboard::Y, sf::Keyboard::Z, sf::Keyboard::Num0, sf::Keyboard::Num1,
                                  sf::Keyboard::Num2, sf::Keyboard::Num3, sf::Keyboard::Num4, sf::Keyboard::Num5,
                                  sf::Keyboard::Num6, sf::Keyboard::Num7, sf::Keyboard::Num8, sf::Keyboard::Num9,
                                  sf::Keyboard::Escape, sf::Keyboard::LControl, sf::Keyboard::LShift,
                                  sf::Keyboard::LAlt, sf::Keyboard::LSystem, sf::Keyboard::RControl,
                                  sf::Keyboard::RShift, sf::Keyboard::RAlt, sf::Keyboard::RSystem,
                                  sf::Keyboard::Menu, sf::Keyboard::LBracket, sf::Keyboard::RBracket,
                                  sf::Keyboard::Semicolon, sf::Keyboard::Comma, sf::Keyboard::Period,
                                  sf::Keyboard::Quote, sf::Keyboard::Slash, sf::Keyboard::Backslash,
                                  sf::Keyboard::Tilde, sf::Keyboard::Equal, sf::Keyboard::Hyphen,
                                  sf::Keyboard::Space, sf::Keyboard::Enter, sf::Keyboard::Backspace,
                                  sf::Keyboard::Tab, sf::Keyboard::PageUp, sf::Keyboard::PageDown,
                                  sf::Keyboard::End, sf::Keyboard::Home, sf::Keyboard::Insert, sf::Keyboard::Delete,
                                  sf::Keyboard::Add, sf::Keyboard::Subtract, sf::Keyboard::Multiply,
                                  sf::Keyboard::Divide, sf::Keyboard::Left, sf::Keyboard::Right, sf::Keyboard::Up,
                                  sf::Keyboard::Down, sf::Keyboard::Numpad0, sf::Keyboard::Numpad1,
                                  sf::Keyboard::Numpad2, sf::Keyboard::Numpad3, sf::Keyboard::Numpad4,
                                  sf::Keyboard::Numpad5, sf::Keyboard::Numpad6, sf::Keyboard::Numpad7,
                                  sf::Keyboard::Numpad8, sf::Keyboard::Numpad9, sf::Keyboard::F1, sf::Keyboard::F2,
                                  sf::Keyboard::F3, sf::Keyboard::F4, sf::Keyboard::F5, sf::Keyboard::F6,
                                  sf::Keyboard::F7, sf::Keyboard::F8, sf::Keyboard::F9, sf::Keyboard::F10,
                                  sf::Keyboard::F11, sf::Keyboard::F12, sf::Keyboard::F13, sf::Keyboard::F14};
void SocketSendTelemetry(const float &angle, const float &player_x, const float &player_y, sf::Clock& clock) {
    sf::Time elapsed = clock.getElapsedTime();
    if (elapsed.asSeconds() >= 0.5f) {
        clock.restart();
        time_t now = time(nullptr);
        tm *ltm = localtime(&now);
        string datetime =
                to_string(ltm->tm_mday) + "/" + to_string(ltm->tm_mon + 1) + "/" + to_string(ltm->tm_year + 1900) + " " +
                to_string(ltm->tm_hour) + ":" + to_string(ltm->tm_min) + ":" + to_string(ltm->tm_sec);
        string keys_string;
        bool is_first = true;
        for (const auto &key: keys) {
            if (sf::Keyboard::isKeyPressed(key)) {
                if (is_first) {
                    keys_string = keys_string + fromKtoS(key);
                    is_first = false;
                } else {
                    keys_string = keys_string + "," + fromKtoS(key);
                }
            }
        }
        string data = "{'toDo' : 'sendTelemetry', 'time': '" + datetime + "', " + "'angle': " + to_string(angle) + ", " +
                      "'player_x': " +
                      to_string(player_x) + ", " + "'player_y':" +
                      to_string(player_y) + ", " + "'keys': '" + keys_string + "'}";
        const char *str = data.c_str();
        socket.send(str, data.size());
    }

}

void DrawGameScene(sf::RenderWindow &window, sf::Sprite sprite) {
    window.draw(sprite);
}

sf::Vector2f GetCenterCoords(sf::Vector2f size, int kf_x, int kf_y) {
    return {WIDTH / 2.f - size.x / 2.f + kf_x, HEIGHT / 2.f - size.y / 2.f + kf_y};

}

bool is_selected_username = false;
bool is_selected_password = false;
TextBox username(15, sf::Color::White, is_selected_username, {200, 50}, 16, sf::Color::Transparent, sf::Color::White,
                 "Username:", false);
TextBox password(15, sf::Color::White, is_selected_password, {200, 50}, 16, sf::Color::Transparent, sf::Color::White,
                 "Password:", true);
Button send("Enter", {100, 50}, 16, sf::Color::Transparent, sf::Color::White);

void AuthSceneInit() {
    username.setPosition(GetCenterCoords(username.getSize(), 0, -100));
    password.setPosition(GetCenterCoords(password.getSize(), 0, 0));
    username.setLimit(true, 15);
    password.setLimit(true, 20);
    send.setPosition(GetCenterCoords(send.getSize(), 0, 100));
    server_response.setFillColor(sf::Color::White);
    server_response.setCharacterSize(20);
    server_response.setPosition(GetCenterCoords(
            (sf::Vector2f) {server_response.getGlobalBounds().width, server_response.getGlobalBounds().height}, -65,
            -220));
    server_response.setString("Asteroids");
}

void drawAuth(sf::RenderWindow &window) {
    username.drawTo(window);
}
int main() {
    AuthSceneInit();
    sf::Font font;
    if (!font.loadFromFile("myfont.ttf")) {
        cout << "error" << endl;
    }
    username.setFont(font);
    password.setFont(font);
    send.setFont(font);
    server_response.setFont(font);
    sf::Texture texture;
    const pair<int, int> object_width_height = {32, 65};
    if (!texture.loadFromFile("ship.png",
                              sf::IntRect(0, 0, object_width_height.first, object_width_height.second))) {
        return -1;
    }
    sf::VertexArray debug_box(sf::LineStrip, 5);
    sf::Sprite sprite;
    sprite.setTexture(texture);
    sprite.setPosition(500.f, 500.f);
    sprite.setOrigin((sf::Vector2f) texture.getSize() / 2.f);
    GameScenes curr_scene;
    curr_scene = GameScenes::AUTH;
    sf::Clock clock;
    vector<ShipAmmo> ammo_container = {};
    vector<Asteroids> asteroids_container = {
            {CreateAsteroid(AsteroidsSize::BIG),    3},
            {CreateAsteroid(AsteroidsSize::MEDIUM), 2}
    };


    float velocity_x = 0;
    float velocity_y = 0;

    int counter = 1001;
    const float velocity = 0.1f;
    while (sfmlWin.isOpen()) {
        sfmlWin.clear();
        MouseInfo mouse;
        sf::Event e;
        while (sfmlWin.pollEvent(e)) {
            switch (e.type) {
                case sf::Event::TextEntered:
                    username.typedOn(e);
                    password.typedOn(e);
                    break;
                case sf::Event::EventType::Closed:
                    sfmlWin.close();
                    break;
            }
            if (curr_scene == GameScenes::AUTH) {
                if (e.type == sf::Event::MouseButtonReleased) {
                    if (e.mouseButton.button == sf::Mouse::Left && username.isMouseOver(sfmlWin)) {
                        cout << "clicked!" << endl;
                        username.setSelected(true);
                        password.setSelected(false);
                    } else if (e.mouseButton.button == sf::Mouse::Left && password.isMouseOver(sfmlWin)) {
                        username.setSelected(false);
                        password.setSelected(true);
                    } else {
                        username.setSelected(false);
                        password.setSelected(false);
                    }
                    if (e.mouseButton.button == sf::Mouse::Left && send.isMouseOver(sfmlWin)) {
                        string msg = "{'toDo' : 'checkUser', 'username' : "s + "'" + username.getText() + "'" +
                                     ", 'password' : "s + "'" +
                                     password.getText() + "'" + "}"s;
                        cout << msg << endl;
                        string code = SendMessTCP(msg);
                        if (code == "200") {
                            server_response.setString("Welcome, " + username.getText());
                            curr_scene = GameScenes::GAME;
                        } else if (code == "404") {
                            server_response.setString("incorrect data");
                        } else {
                            server_response.setString("Server Error");
                        }
                    }
                }
            }
        }
        if (curr_scene == GameScenes::GAME) {
            SetVelocity(velocity_x, velocity_y, mouse, sprite, velocity);
            sprite.move(velocity_x, velocity_y);
            Fire(counter, sprite, mouse, ammo_container);
            SetSmoothVelocity(velocity_x, velocity_y);
            RollBackToScreen(sprite);
            float angle = SetPointToMouse(sprite, mouse);
            IteratingLogic(ammo_container, asteroids_container, sprite);
            DrawGameScene(sfmlWin, sprite);
            SocketSendTelemetry(angle, sprite.getPosition().x, sprite.getPosition().x, clock);
        } else if (curr_scene == GameScenes::AUTH) {
            username.drawTo(sfmlWin);
            password.drawTo(sfmlWin);
            send.drawTo(sfmlWin);
            sfmlWin.draw(server_response);
        }

        sfmlWin.display();
    }
    socket.disconnect();
    return 0;
}