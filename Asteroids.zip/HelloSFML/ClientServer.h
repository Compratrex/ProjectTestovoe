//
// Created by CompratRex on 15.02.2023.
//
#include <string>
#include <SFML/Network.hpp>

class ClientServerHttp{
    ClientServerHttp() {}

    ClientServerHttp(const std::string& host, const int port, ){

    }
};



