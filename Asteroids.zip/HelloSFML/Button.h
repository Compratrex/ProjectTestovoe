//
// Created by CompratRex on 14.02.2023.
//
#include <SFML/Graphics.hpp>

class Button {
public:
    Button() {}

    Button(std::string t, sf::Vector2f size, int charSize, sf::Color bgColor, sf::Color textColor) {
        text.setString(t);
        text.setColor(textColor);
        text.setCharacterSize(charSize);
        button.setSize(size);
        button.setFillColor(bgColor);
        button.setOutlineThickness(2);
        button.setOutlineColor(textColor);
    }

    void setFont(sf::Font &font) {
        text.setFont(font);
    }

    void setBackColor(sf::Color color) {
        button.setFillColor(color);
    }

    void setTextColor(sf::Color color) {
        text.setColor(color);
    }
    sf::Vector2f getSize(){
        return button.getSize();
    }
    void setPosition(sf::Vector2f pos) {
        button.setPosition(pos);

        float x_pos = (pos.x + button.getLocalBounds().width / 2) - (text.getLocalBounds().width / 2) - 25;
        float y_pos = (pos.y + button.getLocalBounds().height / 2) - (text.getLocalBounds().height / 2) - 10;
        text.setPosition({x_pos, y_pos});
    }
    void drawTo(sf::RenderWindow& window){
        window.draw(button);
        window.draw(text);
    }
    bool isMouseOver(sf::RenderWindow& window){
        float mouse_x = sf::Mouse::getPosition(window).x;
        float mouse_y = sf::Mouse::getPosition(window).y;
        float btn_pos_x = button.getPosition().x;
        float btn_pos_y = button.getPosition().y;

        float btnx_pos_width = button.getPosition().x +button.getLocalBounds().width;
        float btny_pos_height = button.getPosition().y +button.getLocalBounds().height;

        if(mouse_x < btnx_pos_width && mouse_x > btn_pos_x && mouse_y < btny_pos_height && mouse_y > btn_pos_y){
            return true;
        }
        return false;
    }

private:
    sf::RectangleShape button;
    sf::Text text;
};
