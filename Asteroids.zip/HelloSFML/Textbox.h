//
// Created by CompratRex on 14.02.2023.
//
#include <SFML/Graphics.hpp>
#include <sstream>

class TextBox {
public:
    TextBox() {}

    TextBox(int text_size, sf::Color color, bool sel, sf::Vector2f size, int charSize, sf::Color bgColor,
            sf::Color textColor, std::string lbl_txt, bool is_password) {
        textbox.setCharacterSize(text_size);
        textbox.setColor(color);
        isSelected = sel;
        box.setSize(size);
        is_password_ = is_password;
        box.setOutlineThickness(2);
        box.setOutlineColor(color);
        box.setFillColor(bgColor);
        label.setString(lbl_txt);
        label.setColor(color);
        label.setCharacterSize(text_size);
        if (sel) {
            textbox.setString("|");
        } else {
            textbox.setString("");
        }
    }

    void setFont(sf::Font &font) {
        textbox.setFont(font);
        label.setFont(font);
    }

    void setLimit(bool ToF, int lim) {
        hasLimit = ToF;
        limit = lim - 1;
    }

    void drawTo(sf::RenderWindow &window) {
        window.draw(box);
        window.draw(textbox);
        window.draw(label);
    }

    void setSelected(bool sel) {
        isSelected = sel;
        if (!sel) {
            std::string t = text.str();
            std::string newT = "";
            for (int i = 0; i < t.length(); ++i) {
                newT += t[i];
            }
            textbox.setString(newT);
        }else{
            textbox.setString(text.str() + "|");
        }
    }

    std::string getText() {
        return text.str();
    }

    void typedOn(sf::Event input) {
        if (isSelected) {
            int charTyped = input.text.unicode;
            if (charTyped < 128) {
                if (hasLimit) {
                    if (text.str().length() <= limit) {
                        inputLog(charTyped);
                    } else if (text.str().length() > limit && charTyped == 8) {
                        deleteLastChar();
                    }
                } else {
                    inputLog(charTyped);
                }
            }
        }
    }

    void setPosition(sf::Vector2f pos) {
        box.setPosition(pos);

        float x_pos = pos.x + 10;
        float y_pos = (pos.y + box.getLocalBounds().height / 2) - (textbox.getLocalBounds().height / 2) - 10;
        textbox.setPosition({x_pos, y_pos});
        label.setPosition({pos.x, pos.y - 25});
    }
    sf::Vector2f getSize(){
        return box.getSize();
    }
    bool isMouseOver(sf::RenderWindow& window){
        float mouse_x = sf::Mouse::getPosition(window).x;
        float mouse_y = sf::Mouse::getPosition(window).y;
        float btn_pos_x = box.getPosition().x;
        float btn_pos_y = box.getPosition().y;

        float btnx_pos_width = box.getPosition().x + box.getLocalBounds().width;
        float btny_pos_height = box.getPosition().y + box.getLocalBounds().height;
//        std::cout << btnx_pos_width << " " << btny_pos_height << " " << mouse_x << " " << mouse_y << std::endl;
        if(mouse_x >= btn_pos_x && mouse_x <= btnx_pos_width && mouse_y >= btn_pos_y && mouse_y <= btny_pos_height){
            return true;
        }

        return false;
    }

private:
    sf::Text textbox;
    sf::Text label;
    sf::RectangleShape box;
    std::ostringstream text;
    bool isSelected = false;
    bool hasLimit = false;
    int limit;
    bool is_password_;

    void inputLog(int typed) {
        if (typed != 8 && typed != 13 && typed != 27) {
            text << static_cast<char>(typed);
        } else if (typed == 8) {
            if (text.str().length() > 0) {
                deleteLastChar();
            }
        }
        textbox.setString(text.str() + "|");
    }

    void deleteLastChar() {
        std::string t = text.str();
        std::string newT = "";
        for (int i = 0; i < t.length() - 1; ++i) {
            newT += t[i];
        }
        text.str("");
        text << newT;

        textbox.setString(text.str());
    }
};