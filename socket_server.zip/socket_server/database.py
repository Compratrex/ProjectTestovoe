import sqlite3
from sqlite3 import Error


def create_connection(db_file):
    conn = None
    try:
        conn = sqlite3.connect(db_file, check_same_thread=False)
        return conn
    except Error as e:
        print(e)


def create_table(conn, create_table_sql):
    try:
        c = conn.cursor()
        c.execute(create_table_sql)
    except Error as e:
        print(e, "opa")


def create_user(conn, username_, password_):
    sql = f"INSERT INTO game_users(username, password, best_score, is_active) VALUES('{username_}','{password_}',0,0)"

    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()
    return cur.lastrowid


def get_all_users(conn):
    cur = conn.cursor()
    cur.execute("""SELECT * FROM game_users""")
    rows = cur.fetchall()
    cur.close()
    return rows


def get_all_temetry(conn):
    curr = conn.cursor()
    curr.execute("SELECT * FROM telemetry")
    rows = curr.fetchall()
    for row in rows:
        print(row)
    curr.close()


def update_user(conn, player_id, is_act):
    sql = f"UPDATE game_users SET is_active = {is_act} WHERE id = {player_id}"
    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()


def check_active(conn, user_id):
    cur = conn.cursor()
    cur.execute(f"SELECT is_active FROM game_users WHERE id = {user_id}")
    rows = cur.fetchall()
    cur.close()
    if rows[0][0] == 0:
        return False
    return True


def check_if_exist(conn, player_username, player_password):
    cur = conn.cursor()
    cur.execute(f"SELECT * FROM game_users WHERE username = '{player_username}' AND password='{player_password}';")
    rows = cur.fetchall()
    cur.close()
    if len(rows) == 0:
        return []
    return rows[0]


def delete_user(conn, user_id):
    cur = conn.cursor()
    cur.execute(f"DELETE FROM telemetry WHERE id_username = {user_id}")
    cur.execute(f"DELETE FROM game_users WHERE id = {user_id}")
    conn.commit()


def create_tables(conn):
    create_query_game_users = """CREATE TABLE IF NOT EXISTS game_users (
                                            id integer PRIMARY KEY,
                                            username text,
                                            password text,
                                            best_score text,
                                            is_active integer
                                        );"""

    create_query_telemetry = """CREATE TABLE IF NOT EXISTS telemetry (
                                            id integer PRIMARY KEY,
                                            id_username integer,
                                            datetime text,
                                            angle real,
                                            player_x real,
                                            player_y real,
                                            keys_codes text
                                        );"""
    try:
        create_table(conn, create_query_game_users)
        create_table(conn, create_query_telemetry)
        print("base created")
    except Error as e:
        print(e)


def insert_telemetry(conn, user_id_, time, angle, player_x, player_y, keys):
    sql = f"INSERT INTO telemetry(id_username, datetime, angle, player_x, player_y, keys_codes) VALUES({user_id_},'{time}',{angle},{player_x},{player_y},'{keys}')"
    cur = conn.cursor()
    cur.execute(sql)
    conn.commit()
    return cur.lastrowid


def get_curr_telemetry(conn, user_id):
    sql = f"SELECT * FROM telemetry WHERE id_username = {user_id}"
    curr = conn.cursor()
    curr.execute(sql)
    rows = curr.fetchall()
    curr.close()
    return rows
