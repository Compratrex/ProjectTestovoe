import socket
from ast import literal_eval
import database

connection = database.create_connection("game_database.db")
database.create_tables(connection)
database.get_all_users(connection)
if not database.check_if_exist(connection,  'admin', 'admin'):
    database.create_user(connection, 'admin', 'admin')
connection.close()
serv_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM, proto=0)
serv_sock.bind(('127.0.0.1', 53210))
serv_sock.listen(1)
print("server started...")
user_id = ''
while True:
    client_sock, client_addr = serv_sock.accept()
    print('Подключено ', client_addr)
    while True:
        data = client_sock.recv(1000)
        if data:
            data = literal_eval(data.decode('utf8'))
            if data['toDo'] == 'checkUser':
                connection = database.create_connection("game_database.db")
                check = database.check_if_exist(connection, data['username'], data['password'])
                if check:
                    client_sock.send(b"200")
                    user_id = check[0]
                    database.update_user(connection, user_id, 1)
                else:
                    client_sock.send(b"404")
            if data['toDo'] == 'sendTelemetry':
                connection = database.create_connection("game_database.db")
                database.insert_telemetry(connection, user_id, data['time'], data['angle'], data['player_x'],
                                          data['player_y'], data['keys'])

        if not data:
            print(client_addr, "Отключен")
            database.update_user(connection, user_id, 0)
            break
    connection.close()
    client_sock.close()
