getUsr();

$('.user-spis').on('click', '.user', function () {
    $.ajax({
        url: '/select-curr-telemetry',
        method: 'POST',
        data: {'user_id': this.id},
        success: function (data) {
            let text = ""
            for (let prop in data) {
                if (data.hasOwnProperty(prop)) {
                    for (let element in data[prop]) {
                        if (data[prop].hasOwnProperty(element)) {
                            text += data[prop][element] + " ";
                        }
                    }
                }
                text += '\r\n'
                $('textarea')[0].innerHTML = text;
            }
        }
    })
});
$('form').submit(function (e) {
    e.preventDefault();
    $.ajax({
        url : '/add-user',
        method: 'POST',
        data : {'username' : $(".usrname")[0].value, 'password' : $(".usrpass")[0].value},
        success: function (){
            getUsr();
        }
    })
});

$('.users_container').on('click', '.delete_user', function (){
    $.ajax({
        url : '/delete-user',
        method : 'POST',
        data : {'user_id' : this.getAttribute('id_')},
        success : function (data){
            is_active = data['active'];
            console.log(data)
            console.log(data['active'])
            console.log(is_active)
            if(is_active){
                alert("Пользователь не может быть удален, потому что он в данный момент активен");
            }else{
                getUsr();
            }
        }
    })
});
function getUsr() {
    clearUsers();
    $.ajax({
        url: '/select-all-from-users',
        success: function (result) {
            for (let prop in result) {
                if (result.hasOwnProperty(prop)) {
                    $('.users_container').append(`<div class="user user_${prop}" id="${prop}"></div><div class="buttons-container"><button class="delete_user" id_="${prop}">удалить</button></div>`);
                    $(`.user_${prop}`).append(`<div class="container"><p>${prop}</p></div>`);
                    for (let element in result[prop]) {
                        if (result[prop].hasOwnProperty(element)) {
                            $(`.user_${prop}`).append(`<div class="container"><p>${result[prop][element]}</p></div>`);
                        }
                    }
                }
            }
        }
    })
}
function clearUsers(){
    $('.users_container')[0].innerHTML = "";
}