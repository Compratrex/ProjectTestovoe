from flask import Flask, render_template
from flask import request
import database
import math

app = Flask(__name__)


@app.route("/")
def index():
    return render_template('index.html')


@app.route("/select-all-from-users", methods=['GET'])
def select():
    conn = database.create_connection('game_database.db')
    data = database.get_all_users(conn)
    dic = {}
    conn.close()
    for i in data:
        dic[i[0]] = {'Имя': i[1], 'Пароль': i[2], 'Лучший результат': i[3], 'В сессии': i[4]}
    return dic


@app.route("/select-curr-telemetry", methods=['POST'])
def telemetry():
    if request.method == 'POST':
        data = request.form['user_id']
        conn = database.create_connection('game_database.db')
        content = database.get_curr_telemetry(conn, data)
        dic = {}
        if len(content) == 0:
            return {1: {'Not Found': "Пользователь еще ни разу не запускал игру"}}
        else:
            for i in content:
                keys = i[6].split(",")
                dic[i[0]] = {1: i[2], 2: 'x: ' + str(math.floor(i[4])), 3: 'y: ' + str(math.floor(i[5])),
                             4: 'yгол: ' + str(math.floor(i[3])) + "°", 5: "Нажатые клавиши: " + str(keys)}
        return dic


@app.route("/add-user", methods=['POST'])
def add_user():
    if request.method == 'POST':
        conn = database.create_connection('game_database.db')
        database.create_user(conn, request.form['username'], request.form['password'])
        return "ok"
    return "not ok"


@app.route("/delete-user", methods=['POST'])
def delete_user():
    if request.method == 'POST':
        conn = database.create_connection('game_database.db')
        is_active = database.check_active(conn, request.form['user_id'])
        if not is_active:
            database.delete_user(conn, request.form['user_id'])
        return {'active' : is_active}



if __name__ == '__main__':
    app.run(host='127.0.0.1', port='8000')
